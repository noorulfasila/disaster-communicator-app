import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/incident_provider.dart';
import 'pages/home_page.dart';
import 'pages/incident_list_page.dart';
import 'pages/incident_map_page.dart';
import 'pages/alerts_page.dart';
import 'pages/notifications_page.dart';

void main() {
  runApp(MultiProvider(
    providers: [ChangeNotifierProvider(create: (_) => IncidentProvider())],
    child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Disaster Dashboard',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF7B1FA2),
        fontFamily: 'Roboto',
      ),
      routes: {
        '/': (_) => const HomePage(),
        '/incidents': (_) => const IncidentListPage(),
        '/incident-map': (_) => const IncidentMapPage(),
        '/alerts': (_) => const AlertsPage(),
        '/notifications': (_) => const NotificationsPage(),
      },
      initialRoute: '/',
    );
  }
}
