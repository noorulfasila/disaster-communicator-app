import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ReportIncidentPage extends StatefulWidget {
  @override
  _ReportIncidentPageState createState() => _ReportIncidentPageState();
}

class _ReportIncidentPageState extends State<ReportIncidentPage> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedDisaster;
  String? _otherDisaster;
  File? _image;
  String? _description;
  String? _urgency;
  String? _city;
  String? _pincode;
  String? _address;
  bool _useCurrentLocation = false;

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Success"),
          content: Text("Updated Successfully"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            )
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Report Incident")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButtonFormField<String>(
                value: _selectedDisaster,
                decoration: InputDecoration(labelText: "Select Disaster Type"),
                items: ["Flood", "Cyclone", "Tsunami", "Earthquake", "Others"]
                    .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedDisaster = value;
                  });
                },
                validator: (value) => value == null ? "Please select a type" : null,
              ),
              if (_selectedDisaster == "Others")
                TextFormField(
                  decoration: InputDecoration(labelText: "Enter Disaster Type"),
                  onSaved: (value) => _otherDisaster = value,
                ),
              SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: _pickImage,
                icon: Icon(Icons.image),
                label: Text("Upload Image"),
              ),
              if (_image != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Image.file(_image!, height: 150),
                ),
              TextFormField(
                decoration: InputDecoration(labelText: "Description"),
                maxLines: 3,
                onSaved: (value) => _description = value,
              ),
              DropdownButtonFormField<String>(
                value: _urgency,
                decoration: InputDecoration(labelText: "Urgency"),
                items: ["Low", "Medium", "High"]
                    .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _urgency = value;
                  });
                },
                validator: (value) => value == null ? "Please select urgency" : null,
              ),
              CheckboxListTile(
                title: Text("Use Current Location"),
                value: _useCurrentLocation,
                onChanged: (val) {
                  setState(() {
                    _useCurrentLocation = val!;
                    if (_useCurrentLocation) {
                      _city = "Chennai";
                      _pincode = "600001";
                      _address = "Dummy Street, Chennai, India";
                    }
                  });
                },
              ),
              if (!_useCurrentLocation) ...[
                TextFormField(
                  decoration: InputDecoration(labelText: "City"),
                  onSaved: (value) => _city = value,
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: "Pincode"),
                  keyboardType: TextInputType.number,
                  onSaved: (value) => _pincode = value,
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: "Address"),
                  onSaved: (value) => _address = value,
                ),
              ],
              SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: _submitForm,
                  child: Text("Submit"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
