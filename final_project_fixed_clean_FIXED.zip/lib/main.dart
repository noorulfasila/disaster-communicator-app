
import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'role_selection_page.dart';
import 'login_page.dart';
import 'signup_page.dart';
import 'people_home_page.dart';
import 'report_incident_page.dart';
import 'profile_page.dart';
import 'alerts_page.dart';
import 'notifications_page.dart';

void main() {
  runApp(const DisasterApp());
}

class DisasterApp extends StatelessWidget {
  const DisasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: Colors.black,
      colorScheme: const ColorScheme.dark(
        primary: Colors.deepPurpleAccent,
        secondary: Colors.purpleAccent,
      ),
      useMaterial3: true,
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Emergency Alert System',
      theme: theme,
      routes: {
        '/': (_) => const RoleSelectionPage(),
        '/login': (_) => const LoginPage(),
        '/signup': (_) => const SignUpPage(),
        '/home': (_) => const PeopleHomePage(),
        ReportIncidentPage.routeName: (_) => const ReportIncidentPage(),
        '/profile': (_) => const ProfilePage(),
        '/alerts': (_) => const AlertsPage(),
        '/notifications': (_) => const NotificationsPage(),
      },
    );
  }
}
